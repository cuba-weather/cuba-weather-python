# cuba-weather

Python3 client for [redcuba.cu](https://www.redcuba.cu) weather API

## Usage

./weather.py "Cienfuegos"

